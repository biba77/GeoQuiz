//not in use sir
package com.example.geoquiz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import com.example.geoquiz2.R

class CheatActivity : ComponentActivity() {

    private lateinit var showAnswerButton: Button
    private var isCheater: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cheat)

        // Initialize the button
        showAnswerButton = findViewById(R.id.showAnswerButton)

        // Restore the state if available
        if (savedInstanceState != null) {
            isCheater = savedInstanceState.getBoolean(KEY_IS_CHEATER, false)
        }

        // Set up the click listener
        showAnswerButton.setOnClickListener {
            isCheater = true
            setCheaterResult(isCheater)
        }
    }

    private fun setCheaterResult(isCheater: Boolean) {
        val data = Intent().apply {
            putExtra(EXTRA_ANSWER_SHOWN, isCheater)
        }
        setResult(Activity.RESULT_OK, data)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_IS_CHEATER, isCheater)
    }

    companion object {
        const val EXTRA_ANSWER_SHOWN = "com.example.geoquiz2.answer_shown"
        private const val KEY_IS_CHEATER = "is_cheater"

        fun newIntent(packageContext: Activity): Intent {
            return Intent(packageContext, CheatActivity::class.java)
        }
    }
}
