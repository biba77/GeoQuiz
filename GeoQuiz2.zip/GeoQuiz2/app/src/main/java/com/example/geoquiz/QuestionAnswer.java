package com.example.geoquiz;

public class QuestionAnswer {

    public static String question [] = {
            "Which country has the Eiffel Tower?",
            "Which country is known as Land of the Rising Sun?",
            "Which country is famous for its Amazon Rainforest?",
            "Which country has a maple leaf on its flag?",
            "Which country has the Great Pyramids of Giza",
            "Which country has the hardest language in the world?",
            "Which country in the world that only starts with that letter?",
            "Which country is the homeland of Adolf Hitler?",
            "Which country is the home of Taj Mahal?",
            "Which country is known for the Sydney Opera House"

    };

    public static String choices [] [] = {
            {"Spain", "France", "Croatia", "UK"},
            {"Japan", "South Korea", "Vietnam", "Bangladesh"},
            {"Australia", "South Africa", "Malaysia", "Brazil"},
            {"San Marino", "Ireland", "Canada", "Ivory Coast"},
            {"UAE", "Egypt", "Sudan", "Oman"},
            {"China", "Saudi Arabia", "Japan", "Portugal"},
            {"Zimbabwe", "Seychelles", "Jordan", "Oman"},
            {"Italy", "France", "Germany", "Austria"},
            {"Pakistan", "India", "Bangladesh", "Uzbekistan"},
            {"Australia", "New Zealand", "USA", "Qatar"}


    };

    public static String correctAnswers []= {
            "France",
            "Japan",
            "Brazil",
            "Canada",
            "Egypt",
            "China",
            "Oman",
            "Germany",
            "India",
            "Australia"
    };
}
