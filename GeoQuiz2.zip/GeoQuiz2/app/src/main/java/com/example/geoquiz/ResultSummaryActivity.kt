package com.example.geoquiz

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.widget.LinearLayout
import android.view.LayoutInflater
import android.widget.Button
import com.example.geoquiz2.R

class ResultSummaryActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result_summary)

        val score = intent.getIntExtra("score", 0)
        val totalQuestions = intent.getIntExtra("totalQuestions", 0)
        val answersGiven = intent.getSerializableExtra("answersGiven") as Array<Pair<Int, String>>
        val cheatTokensUsed = intent.getIntExtra("cheatTokensUsed", 0)

        val textResultSummary = findViewById<TextView>(R.id.text_result_summary)
        textResultSummary.text =
            "Total Questions Answered: ${answersGiven.size}\nTotal Score: $score\nTotal Cheat Attempts: $cheatTokensUsed"

        val containerQuestions = findViewById<LinearLayout>(R.id.container_questions)

        // Inflate and add the question result views
        for ((index, answer) in answersGiven) {
            val itemView = LayoutInflater.from(this)
                .inflate(R.layout.item_question_result, containerQuestions, false)
            val textQuestion = itemView.findViewById<TextView>(R.id.text_question)
            val textSelectedAnswer = itemView.findViewById<TextView>(R.id.text_selected_answer)
            val textCorrectAnswer = itemView.findViewById<TextView>(R.id.text_correct_answer)

            textQuestion.text = QuestionAnswer.question[index]
            textSelectedAnswer.text = "Selected Answer: $answer"
            textCorrectAnswer.text = "Correct Answer: ${QuestionAnswer.correctAnswers[index]}"

            containerQuestions.addView(itemView)
        }

        val buttonRestartQuiz = findViewById<Button>(R.id.button_restart_quiz)
        buttonRestartQuiz.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}