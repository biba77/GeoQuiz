package com.example.geoquiz

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.geoquiz2.R

class QuizActivity : ComponentActivity(), View.OnClickListener {

    private lateinit var totalQuestionsTextView: TextView
    private lateinit var questionTextView: TextView
    private lateinit var ansA: Button
    private lateinit var ansB: Button
    private lateinit var ansC: Button
    private lateinit var ansD: Button
    private lateinit var cheatBtn: Button
    private lateinit var nextBtn: Button
    private lateinit var previousBtn: Button
    private lateinit var resetBtn: Button
    private lateinit var resultSummaryBtn: Button
    private lateinit var submitBtn: Button
    private lateinit var questionButtons: Array<Button>

    private var score: Int = 0
    private val totalQuestion: Int = QuestionAnswer.question.size
    private var currentQuestionIndex: Int = 0
    private var selectedAnswerIndex: Int = -1 // Track selected answer index
    private var isCheater: Boolean = false
    private var cheatTokens: Int = 3
    private val answersGiven = mutableMapOf<Int, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        totalQuestionsTextView = findViewById(R.id.total_question)
        questionTextView = findViewById(R.id.question)
        ansA = findViewById(R.id.ans_A)
        ansB = findViewById(R.id.ans_B)
        ansC = findViewById(R.id.ans_C)
        ansD = findViewById(R.id.ans_D)
        cheatBtn = findViewById(R.id.cheat_btn)
        nextBtn = findViewById(R.id.next_btn)
        previousBtn = findViewById(R.id.previous_btn)
        resetBtn = findViewById(R.id.reset_btn)
        resultSummaryBtn = findViewById(R.id.resultSummaryButton)
        submitBtn = findViewById(R.id.submit_btn)
        questionButtons = arrayOf(
            findViewById(R.id.button_1),
            findViewById(R.id.button_2),
            findViewById(R.id.button_3),
            findViewById(R.id.button_4),
            findViewById(R.id.button_5),
            findViewById(R.id.button_6),
            findViewById(R.id.button_7),
            findViewById(R.id.button_8),
            findViewById(R.id.button_9),
            findViewById(R.id.button_10)
        )

        // Set click listeners
        ansA.setOnClickListener(this)
        ansB.setOnClickListener(this)
        ansC.setOnClickListener(this)
        ansD.setOnClickListener(this)
        cheatBtn.setOnClickListener(this)
        nextBtn.setOnClickListener(this)
        previousBtn.setOnClickListener(this)
        resetBtn.setOnClickListener(this)
        resultSummaryBtn.setOnClickListener(this)
        submitBtn.setOnClickListener(this)
        questionButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                currentQuestionIndex = index
                loadNewQuestion()
            }
        }

        // Initialize the UI with the first question
        loadNewQuestion()
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.ans_A -> {
                Log.d("QuizActivity", "Answer A selected")
                selectedAnswerIndex = 0
                answersGiven[currentQuestionIndex] = QuestionAnswer.choices[currentQuestionIndex][0]
                highlightSelectedAnswer()
            }
            R.id.ans_B -> {
                Log.d("QuizActivity", "Answer B selected")
                selectedAnswerIndex = 1
                answersGiven[currentQuestionIndex] = QuestionAnswer.choices[currentQuestionIndex][1]
                highlightSelectedAnswer()
            }
            R.id.ans_C -> {
                Log.d("QuizActivity", "Answer C selected")
                selectedAnswerIndex = 2
                answersGiven[currentQuestionIndex] = QuestionAnswer.choices[currentQuestionIndex][2]
                highlightSelectedAnswer()
            }
            R.id.ans_D -> {
                Log.d("QuizActivity", "Answer D selected")
                selectedAnswerIndex = 3
                answersGiven[currentQuestionIndex] = QuestionAnswer.choices[currentQuestionIndex][3]
                highlightSelectedAnswer()
            }
            R.id.cheat_btn -> handleCheat()
            R.id.next_btn -> moveToNextQuestion()
            R.id.previous_btn -> moveToPreviousQuestion()
            R.id.reset_btn -> resetQuiz()
            R.id.resultSummaryButton -> showResultSummary()
            R.id.submit_btn -> showScoreToast()
        }
    }

    private fun handleCheat() {
        if (cheatTokens > 0) {
            cheatTokens--
            isCheater = true
            updateCheatButtonText()
            revealCorrectAnswer()
        }
    }

    private fun revealCorrectAnswer() {
        val correctAnswer = QuestionAnswer.correctAnswers[currentQuestionIndex]
        when {
            ansA.text == correctAnswer -> ansA.setBackgroundColor(Color.GREEN)
            ansB.text == correctAnswer -> ansB.setBackgroundColor(Color.GREEN)
            ansC.text == correctAnswer -> ansC.setBackgroundColor(Color.GREEN)
            ansD.text == correctAnswer -> ansD.setBackgroundColor(Color.GREEN)
            else -> {
                // If the correct answer is not found among the choices, you can handle it here
                Log.e("QuizActivity", "Correct answer not found among choices")
            }
        }
    }

    private fun updateCheatButtonText() {
        cheatBtn.text = "Cheat($cheatTokens)"
        cheatBtn.isEnabled = cheatTokens > 0
    }

    private fun moveToNextQuestion() {
        if (currentQuestionIndex < totalQuestion - 1) {
            currentQuestionIndex++
            loadNewQuestion()
        }
    }

    private fun moveToPreviousQuestion() {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--
            loadNewQuestion()
        }
    }

    private fun loadNewQuestion() {
        questionTextView.text = QuestionAnswer.question[currentQuestionIndex]
        ansA.text = QuestionAnswer.choices[currentQuestionIndex][0]
        ansB.text = QuestionAnswer.choices[currentQuestionIndex][1]
        ansC.text = QuestionAnswer.choices[currentQuestionIndex][2]
        ansD.text = QuestionAnswer.choices[currentQuestionIndex][3]
        totalQuestionsTextView.text = "Question ${currentQuestionIndex + 1} of $totalQuestion"
        resetAnswerButtons()
        updateQuestionButtonColors()
        updateCheatButtonText()

        // Highlight the previously selected answer if it exists
        val selectedAnswer = answersGiven[currentQuestionIndex]
        selectedAnswerIndex = when (selectedAnswer) {
            QuestionAnswer.choices[currentQuestionIndex][0] -> 0
            QuestionAnswer.choices[currentQuestionIndex][1] -> 1
            QuestionAnswer.choices[currentQuestionIndex][2] -> 2
            QuestionAnswer.choices[currentQuestionIndex][3] -> 3
            else -> -1
        }
        highlightSelectedAnswer()

        // Show or hide next and submit buttons based on the current question index
        if (currentQuestionIndex == totalQuestion - 1) {
            nextBtn.visibility = View.GONE
            submitBtn.visibility = View.VISIBLE
        } else {
            nextBtn.visibility = View.VISIBLE
            submitBtn.visibility = View.GONE
        }
    }


    private fun resetAnswerButtons() {
        ansA.setBackgroundResource(R.drawable.button_selector)
        ansB.setBackgroundResource(R.drawable.button_selector)
        ansC.setBackgroundResource(R.drawable.button_selector)
        ansD.setBackgroundResource(R.drawable.button_selector)
    }

    private fun highlightSelectedAnswer() {
        resetAnswerButtons()
        when (selectedAnswerIndex) {
            0 -> ansA.setBackgroundColor(resources.getColor(R.color.purple_500))
            1 -> ansB.setBackgroundColor(resources.getColor(R.color.purple_500))
            2 -> ansC.setBackgroundColor(resources.getColor(R.color.purple_500))
            3 -> ansD.setBackgroundColor(resources.getColor(R.color.purple_500))
        }
    }

    private fun updateQuestionButtonColors() {
        for (i in questionButtons.indices) {
            questionButtons[i].setBackgroundColor(if (i == currentQuestionIndex) Color.GRAY else Color.LTGRAY)
        }
    }

    private fun resetQuiz() {
        score = 0
        currentQuestionIndex = 0
        selectedAnswerIndex = -1
        isCheater = false
        cheatTokens = 3
        answersGiven.clear()
        updateCheatButtonText()
        nextBtn.visibility = View.VISIBLE
        submitBtn.visibility = View.GONE
        loadNewQuestion()
    }

    private fun showResultSummary() {
        // Calculate the score based on the correct answers and any cheating attempts
        score = answersGiven.entries.count { (index, answer) ->
            answer == QuestionAnswer.correctAnswers[index]
        }

        val intent = Intent(this, ResultSummaryActivity::class.java).apply {
            putExtra("score", score)
            putExtra("totalQuestions", totalQuestion)
            putExtra("answersGiven", answersGiven.map { it.toPair() }.toTypedArray())
            putExtra("cheatTokensUsed", 3 - cheatTokens) // Pass the number of cheat attempts
        }
        startActivity(intent)
    }

    private fun showScoreToast() {
        val correctAnswers = QuestionAnswer.correctAnswers
        var correctCount = 0

        for ((index, answer) in answersGiven) {
            if (answer == correctAnswers[index]) {
                correctCount++
            }
        }

        val scorePercentage = (correctCount.toDouble() / totalQuestion) * 100
        val scoreMessage = "Your score: %.2f%%".format(scorePercentage)
        Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show()
    }
}
